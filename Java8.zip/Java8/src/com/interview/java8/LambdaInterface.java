package com.interview.java8;

@FunctionalInterface
public interface LambdaInterface {

	public int getSquare(int x);
}
