package com.interview.java8;

public class FunctionalInterfaceTest implements FunctionalInterfaceDemo {

	@Override
	public void test() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void defaultMethod() {
		System.out.println("default method");
	}

}
