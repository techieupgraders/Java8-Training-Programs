package com.demo;

import java.lang.reflect.RecordComponent;

public class App 
{
	//record User(String username) {}
	
	void getRecord() {
		 record User(String username) {}
		 //User record can be used similar to local class
	}
	public static void main(String[] args) {
		Employee e1 = new Employee(101,"John");
		System.out.println(e1);
		e1.show();
		System.out.println(e1.name());

		Employee e2 = new Employee(102,"Jenny");
		System.out.println(e2);

		System.out.println(e1.equals(e2));


		Employee e3 = new Employee(989, null);
		System.out.println(e3);

		//System.out.println(e1.id() + " "+ e1.name());
		e1.name();
		e1.getMoney();
		e1.getEmp("Pune");
		
		
		//User u1 = new User("Mary");
		//System.out.println(u1);
		
		System.out.println("Record or not ? "+Employee.class.isRecord());
		
		RecordComponent[] rc =  Employee.class.getRecordComponents() ;
		
		System.out.println("Record components : "+rc[0].getName()+" "+rc[1].getName());


	}

}
