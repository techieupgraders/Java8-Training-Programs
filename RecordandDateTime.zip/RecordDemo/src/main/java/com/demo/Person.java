package com.demo;

public record Person(int id, String name)
{

}
