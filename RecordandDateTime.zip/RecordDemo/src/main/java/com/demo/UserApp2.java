package com.demo;

import java.time.LocalTime;

public class UserApp2 
{
	public static void main(String[] args) {
		// LocalTime - it represents the time without date and zonal information
		
		LocalTime current= LocalTime.now();
		System.out.println(current);
		
		System.out.println(current.plusHours(10));
		System.out.println(current.minusMinutes(30));
		System.out.println("Hr is "+current.getHour());
		System.out.println("Min are "+ current.getMinute());
		System.out.println(current.isAfter(current.plusHours(10)));
		
		System.out.println(LocalTime.MAX);
	}

}
