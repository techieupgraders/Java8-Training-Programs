package com.demo;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;


public record Product <User extends Object>(  int id, String name, double price) {
	//int id, String name, double price are components in header 
	//and curly bracket record body
}	
	//parameterized constructor, accessors, hashcode, equal, toString
	
//	public final class Product{
//		private final int id;
//		private final String name;
//		private final double price;
//		Product(int id, String name, double price)
//		{
//			//id, name and price
//		}
//		 
//		public int id() {return this.id;}
//		public String name() {return this.name();}
//		public double price() {return this.price;}
//		
//		//equals, hashcode, toString
//	}
	



