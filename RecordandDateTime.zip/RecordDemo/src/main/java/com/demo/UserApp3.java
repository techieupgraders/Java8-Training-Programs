package com.demo;
import java.util.*;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class UserApp3 
{
	public static void main(String[] args) {
		LocalDateTime current= LocalDateTime.now();
		System.out.println("Current "+current);
		
		LocalDateTime c2= LocalDateTime.of(2010, Month.JUNE, 23, 11, 15);
		System.out.println(c2);
		
		LocalDateTime c3 = LocalDateTime.parse("2020-12-13T11:09:12.3127");
		System.out.println(c3);
		
		ZonedDateTime zone1 = ZonedDateTime.now();
		System.out.println(zone1);
		
		DateTimeFormatter pattern1 = DateTimeFormatter.ofPattern("dd/mm/yyyy HH::mm::ss");
		DateTimeFormatter pat2= DateTimeFormatter.ofPattern("dd/mm/yyyy");
		
		String c4 = pat2.format(current);
		System.out.println(c4);
		
		//for FULL and LONG format styles , we require the Timezone 
		String newTime = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT).format(current);
		System.out.println(newTime);;
	}
}
