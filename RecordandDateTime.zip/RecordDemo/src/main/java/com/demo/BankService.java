package com.demo;

public interface BankService {

	void getMoney();
}
