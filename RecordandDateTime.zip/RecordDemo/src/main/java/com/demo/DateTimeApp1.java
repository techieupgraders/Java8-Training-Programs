package com.demo;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.StringTokenizer;

public class DateTimeApp1
{
	public static void main(String[] args) 
	{
		LocalDate bdate= LocalDate.now();		
		User u1 = new User("John", bdate);
		System.out.println("Baby born today is "+u1.getUsername()+" on "+u1.getDateOfBirth());

		LocalDate date2= LocalDate.of(2010, 11, 22).minusMonths(2);
		System.out.println("Date2 is "+date2);

		LocalDate date3= LocalDate.parse("2017-10-21").plusDays(10);

		System.out.println(date3);

		DayOfWeek day = bdate.getDayOfWeek();
		System.out.println(day);

		int month = bdate.getMonthValue();
		System.out.println("Month is "+month);

		System.out.println("bdate is after "+date2+" or not ?"+bdate.isAfter(date2));

		System.out.println("bdate is before "+date3+" or not ?"+bdate.isBefore(date3));

		//StringTokenizer tokens=  new StringTokenizer(date3.toString());
		//StringTokenizer tokens1=  new StringTokenizer(date3.toString(),"-");
		StringTokenizer tokens1=  new StringTokenizer(date3.toString(),"-", false);

		//countTokens()- count of no of times the the nextToken() can be called
		System.out.println("Tokens generated are "+tokens1.countTokens()); //3

		while(tokens1.hasMoreTokens())
		{
			System.out.println("Tokens generated are "+tokens1.countTokens());//3, then 2, then 1
			System.out.println(tokens1.nextToken());
		}

	}


}
