package com.demo;

import java.time.LocalDate;

public class User 
{
	private String username;
	private LocalDate dateOfBirth;
	public User(String username, LocalDate dateOfBirth) {
		super();
		this.username = username;
		this.dateOfBirth = dateOfBirth;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", dateOfBirth=" + dateOfBirth + "]";
	}
	
	

}
