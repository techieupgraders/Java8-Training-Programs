package com.demo;

import java.util.Objects;

public record Employee(int id, String name) implements BankService //header with two components id and name	
{
	static String city;
	
	//	public Employee
	//	{
	//		
	//		System.out.println("Employee constructor called.."+super.getClass().getName());
	//	}

	//canonical constructor
	//	public Employee(int id, String name)
	//	{
	//		if(id<=100)
	//		{
	//			throw new IllegalArgumentException("ID is Invalid");
	//		}
	//		this.id=id;
	//		this.name= name;
	//	}

	//compact constructor , this is not NO_ARG constructor
	public Employee
	{

		if(id<=100)
		{
			throw new IllegalArgumentException("ID is Invalid");
		}
		//implicitly it sets the values for field/components
	}

	public void show()
	{
		System.out.println("ID is "+id+" and name is "+name);
	}

	public String name() 
	{
		System.out.println("Name from accessor is "+name);
		return name;		
	}

	@Override
	public void getMoney() 
	{
		System.out.println("Employee gives money on behalf of Bank!!!");
	}

	//overriding the toString ()
	//	public String toString()
	//	{
	//		return this.name+"*****";
	//	}

	//nested classes and interfaces can be added
	//also nested record can be added which are implicitly static
	
	public record PermanentEmployee(String office)	{}
	
	public void getEmp(String city)
	{
		
		PermanentEmployee pe = new PermanentEmployee(city);
		System.out.println(pe);
	}

}


/*
 * public class Employee { private int id; private String name;
 * 
 * public Employee() { // TODO Auto-generated constructor stub }
 * 
 * public Employee(int id, String name) { super(); this.id = id; this.name =
 * name; }
 * 
 * public int getId() { return id; }
 * 
 * public void setId(int id) { this.id = id; }
 * 
 * public String getName() { return name; }
 * 
 * public void setName(String name) { this.name = name; }
 * 
 * @Override public String toString() { return "Employee [id=" + id + ", name="
 * + name + "]"; }
 * 
 * @Override public int hashCode() { return Objects.hash(id, name); }
 * 
 * @Override public boolean equals(Object obj) { if (this == obj) return true;
 * if (obj == null) return false; if (getClass() != obj.getClass()) return
 * false; Employee other = (Employee) obj; return id == other.id &&
 * Objects.equals(name, other.name); }
 * 
 * }
 */
